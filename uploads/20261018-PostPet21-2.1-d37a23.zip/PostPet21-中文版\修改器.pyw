"""PostPet 2.1 修改器（tkinter）。

只做三件事，每件事一个区域，按钮上写清楚会做什么：
  1. 连上游戏      启动 PP21.exe，或者附加到已经开着的游戏
  2. 照顾宠物      直接点菜单里的功能（宠物状态 / 喂食 / 洗澡 / 陪玩 / 打扫）
  3. 存档          备份、还原（游戏退出时会自己写 PostPetConfig.ppc）
数值搜索也留着，但界面里写明了：只有"能在游戏里看到数字变化"的值才搜得到。

内存布局靠 ReadProcessMemory 直读，任何一步失败都只在底部状态行报错，不弹窗、不崩。
"""
import ctypes
import ctypes.wintypes as w
import os
import shutil
import subprocess
import tkinter as tk
from tkinter import ttk

k32 = ctypes.windll.kernel32
k32.OpenProcess.restype = w.HANDLE
k32.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]
k32.ReadProcessMemory.argtypes = [w.HANDLE, ctypes.c_void_p, ctypes.c_void_p,
                                  ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)]
k32.WriteProcessMemory.argtypes = [w.HANDLE, ctypes.c_void_p, ctypes.c_void_p,
                                   ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)]
k32.VirtualQueryEx.restype = ctypes.c_size_t
u32 = ctypes.windll.user32

PROCESS_ALL = 0x438          # QUERY_INFORMATION | VM_OPERATION | VM_READ | VM_WRITE
MEM_COMMIT = 0x1000
MENU = {
    'status': (16, '宠物状态'),
    'feed': (22, '喂食'),
    'bath': (17, '洗澡'),
    'toys': (25, '陪玩'),
    'clean': (27, '打扫'),
}
MAIN_TITLE = 'PostPet ('


def find_app():
    here = os.path.dirname(os.path.abspath(__file__))
    for cand in (os.path.join(here, 'PostPet21'),
                 here,
                 os.path.join(os.path.dirname(here), 'PostPet21')):
        if os.path.isfile(os.path.join(cand, 'PP21.exe')):
            return cand
    return None


class MBI(ctypes.Structure):
    _fields_ = [('BaseAddress', ctypes.c_void_p), ('AllocationBase', ctypes.c_void_p),
                ('AllocationProtect', w.DWORD), ('RegionSize', ctypes.c_size_t),
                ('State', w.DWORD), ('Protect', w.DWORD), ('Type', w.DWORD)]


class Game:
    """One running PP21.exe."""

    def __init__(self, pid):
        self.pid = pid
        self.h = k32.OpenProcess(PROCESS_ALL, False, pid)
        if not self.h:
            raise OSError('无法打开游戏进程（请用管理员身份运行本工具）')


class Trainer:
    def __init__(self, root):
        self.root = root
        self.app = find_app()
        self.game = None
        self.cands = []
        root.title('PostPet 修改器')
        root.resizable(False, False)
        self.msg = tk.StringVar(value='先点「启动游戏」，再按下面的按钮照顾宠物。')
        self.status = tk.StringVar(value='未连接')
        self.value = tk.StringVar(value='100')
        self.newval = tk.StringVar(value='999')
        self.size = tk.StringVar(value='4 字节')
        self._buttons()
        root.after(600, self._auto_attach)

    # ---------- UI ----------
    def _buttons(self):
        pad = dict(padx=6, pady=4)
        head = ttk.Label(self.root, textvariable=self.status, font=('Microsoft YaHei', 10, 'bold'))
        head.pack(anchor='w', **pad)

        box = ttk.LabelFrame(self.root, text=' 1. 连上游戏 ')
        box.pack(fill='x', padx=8, pady=(2, 6))
        ttk.Button(box, text='启动游戏', command=self.start_game).pack(side='left', **pad)
        ttk.Button(box, text='重新连接', command=self._auto_attach).pack(side='left', **pad)

        box = ttk.LabelFrame(self.root, text=' 2. 照顾宠物（等于点游戏里的菜单） ')
        box.pack(fill='x', padx=8, pady=6)
        for key, (mid, label) in MENU.items():
            ttk.Button(box, text=label,
                       command=lambda i=mid, n=label: self.menu(i, n)).pack(side='left', **pad)

        box = ttk.LabelFrame(self.root, text=' 3. 存档（改坏了可以还原） ')
        box.pack(fill='x', padx=8, pady=6)
        ttk.Button(box, text='备份存档', command=self.backup).pack(side='left', **pad)
        ttk.Button(box, text='还原存档', command=self.restore).pack(side='left', **pad)

        box = ttk.LabelFrame(self.root, text=' 4. 改数值（只对"游戏中能看到变化"的数字有效） ')
        box.pack(fill='x', padx=8, pady=6)
        row = ttk.Frame(box)
        row.pack(fill='x', padx=4, pady=2)
        ttk.Label(row, text='现在游戏里的数值').pack(side='left')
        ttk.Entry(row, textvariable=self.value, width=10).pack(side='left', padx=4)
        ttk.Combobox(row, textvariable=self.size, width=8, state='readonly',
                     values=('1 字节', '2 字节', '4 字节')).pack(side='left')
        ttk.Button(row, text='① 首次搜索', command=self.first_scan).pack(side='left', padx=4)

        row = ttk.Frame(box)
        row.pack(fill='x', padx=4, pady=2)
        ttk.Label(row, text='游戏里让它变化后，输入新数值').pack(side='left')
        ttk.Entry(row, textvariable=self.newval, width=10).pack(side='left', padx=4)
        ttk.Button(row, text='② 再搜索', command=self.refine).pack(side='left', padx=4)

        self.listbox = tk.Listbox(box, height=5)
        self.listbox.pack(fill='x', padx=4, pady=4)
        row = ttk.Frame(box)
        row.pack(fill='x', padx=4, pady=(0, 6))
        ttk.Label(row, text='把选中项改成').pack(side='left')
        self.write_val = tk.StringVar(value='999')
        ttk.Entry(row, textvariable=self.write_val, width=10).pack(side='left', padx=4)
        ttk.Button(row, text='③ 写入选中', command=self.write_selected).pack(side='left', padx=4)
        ttk.Button(row, text='写入全部', command=self.write_all).pack(side='left', padx=4)
        ttk.Button(row, text='清空列表', command=self.clear).pack(side='left', padx=4)

        ttk.Label(self.root, textvariable=self.msg, wraplength=430,
                  foreground='#444').pack(anchor='w', padx=10, pady=(0, 8))

    # ---------- helpers ----------
    def say(self, text):
        self.msg.set(text)
        self.root.update_idletasks()

    def fail(self, err):
        self.say('出错了：%s（游戏没关的话可以继续用）' % err)

    def _auto_attach(self):
        pid = self._find_pid()
        if not pid:
            self.status.set('未连接：先点「启动游戏」')
            return
        try:
            self.game = Game(pid)
            self.status.set('已连接  PP21.exe  (pid %d)' % pid)
            self.say('已连上。要先看宠物状态就点「宠物状态」。')
        except OSError as e:
            self.fail(e)

    def _find_pid(self):
        # 找窗口标题以 PostPet ( 开头的顶层窗口，拿它的进程 id
        found = []

        @ctypes.WINFUNCTYPE(w.BOOL, w.HWND, w.LPARAM)
        def cb(hwnd, _):
            n = u32.GetWindowTextLengthW(hwnd)
            if n:
                buf = ctypes.create_unicode_buffer(n + 1)
                u32.GetWindowTextW(hwnd, buf, n + 1)
                if buf.value.startswith(MAIN_TITLE):
                    pid = w.DWORD()
                    u32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                    found.append(pid.value)
            return True

        u32.EnumWindows(cb, 0)
        return found[0] if found else None

    def _main_hwnd(self):
        found = []

        @ctypes.WINFUNCTYPE(w.BOOL, w.HWND, w.LPARAM)
        def cb(hwnd, _):
            n = u32.GetWindowTextLengthW(hwnd)
            if n:
                buf = ctypes.create_unicode_buffer(n + 1)
                u32.GetWindowTextW(hwnd, buf, n + 1)
                if buf.value.startswith(MAIN_TITLE):
                    found.append(hwnd)
            return True

        u32.EnumWindows(cb, 0)
        return found[0] if found else None

    # ---------- actions ----------
    def start_game(self):
        if not self.app:
            self.say('没找到 PP21.exe：请把本文件放在 PostPet21 文件夹旁边。')
            return
        exe = os.path.join(self.app, 'PP21.exe')
        if self._find_pid():
            self.say('游戏已经在跑了，直接「重新连接」就行。')
            self._auto_attach()
            return
        try:
            subprocess.Popen([exe], cwd=self.app, close_fds=True,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError as e:
            self.fail(e)
            return
        self.status.set('正在启动…')
        self.root.after(9000, self._auto_attach)

    def menu(self, menu_id, label):
        if not self._ensure():
            return
        hwnd = self._main_hwnd()
        if not hwnd:
            self.say('没找到游戏主窗口，先启动游戏。')
            return
        u32.PostMessageW(hwnd, 0x0111, menu_id, 0)     # WM_COMMAND
        self.say('已点「%s」。' % label)

    def _config(self):
        return os.path.join(self.app or '', 'PostPetConfig.ppc')

    def backup(self):
        src = self._config()
        if not os.path.isfile(src):
            self.say('还没有存档文件：先进游戏玩一会儿，正常关掉游戏再备份。')
            return
        dst = src + '.manual.bak'
        try:
            shutil.copy2(src, dst)
        except OSError as e:
            self.fail(e)
            return
        self.say('已备份到 %s' % os.path.basename(dst))

    def restore(self):
        src = self._config() + '.manual.bak'
        if not os.path.isfile(src):
            self.say('没有找到备份文件，先点「备份存档」。')
            return
        if self._find_pid():
            self.say('游戏还开着，先正常关掉游戏再还原，否则会被覆盖。')
            return
        try:
            shutil.copy2(src, self._config())
        except OSError as e:
            self.fail(e)
            return
        self.say('已还原存档。')

    def _ensure(self):
        if not self.game:
            self._auto_attach()
        if not self.game:
            self.say('还没连上游戏：先点「启动游戏」。')
            return False
        return True

    # ---------- value search ----------
    def _size(self):
        return {'1 字节': 1, '2 字节': 2, '4 字节': 4}[self.size.get()]

    def _decode(self, raw):
        n = self._size()
        return int.from_bytes(raw[:n], 'little')

    def _pattern(self, value):
        return int(value).to_bytes(self._size(), 'little', signed=False)

    def _regions(self):
        addr = 0
        mbi = MBI()
        while addr < 0x7FFFFFFF:
            if not k32.VirtualQueryEx(self.game.h, ctypes.c_void_p(addr),
                                      ctypes.byref(mbi), ctypes.sizeof(mbi)):
                break
            if mbi.State == MEM_COMMIT and mbi.Protect & 0xEE and mbi.RegionSize < (64 << 20):
                yield addr, mbi.RegionSize
            addr += mbi.RegionSize

    def first_scan(self):
        if not self._ensure():
            return
        try:
            pat = self._pattern(self.value.get())
        except ValueError:
            self.say('数值要填数字。')
            return
        hits = []
        for base, size in self._regions():
            buf = ctypes.create_string_buffer(size)
            got = ctypes.c_size_t(0)
            if not k32.ReadProcessMemory(self.game.h, ctypes.c_void_p(base), buf, size,
                                         ctypes.byref(got)):
                continue
            data = buf.raw[:got.value]
            i = data.find(pat)
            while i >= 0:
                hits.append(base + i)
                i = data.find(pat, i + 1)
        self.cands = hits
        self._show()
        self.say('首次搜索到 %d 个地址。现在回游戏让这个数值变化，再填新数值点「再搜索」。'
                 % len(hits))

    def refine(self):
        if not self._ensure():
            return
        try:
            pat = self._pattern(self.newval.get())
        except ValueError:
            self.say('数值要填数字。')
            return
        keep = []
        for addr in self.cands:
            buf = ctypes.create_string_buffer(len(pat))
            got = ctypes.c_size_t(0)
            if k32.ReadProcessMemory(self.game.h, ctypes.c_void_p(addr), buf, len(pat),
                                     ctypes.byref(got)) and buf.raw[:got.value] == pat:
                keep.append(addr)
        self.cands = keep
        self._show()
        self.say('再搜索剩下 %d 个地址。选中一个点「写入选中」。' % len(keep))

    def write_selected(self):
        if not self.cands:
            self.say('列表是空的，先搜索。')
            return
        sel = self.listbox.curselection()
        if not sel:
            self.say('先在列表里点一个地址。')
            return
        self._write([self.cands[sel[0]]])

    def write_all(self):
        if not self.cands:
            self.say('列表是空的，先搜索。')
            return
        self._write(self.cands)

    def _write(self, addrs):
        try:
            raw = self._pattern(self.write_val.get())
        except ValueError:
            self.say('要写入的数值要填数字。')
            return
        done = 0
        for addr in addrs:
            if k32.WriteProcessMemory(self.game.h, ctypes.c_void_p(addr),
                                      ctypes.c_char_p(raw), len(raw), None):
                done += 1
        self.say('写入 %d / %d 个地址。' % (done, len(addrs)))

    def _show(self):
        self.listbox.delete(0, 'end')
        for addr in self.cands[:200]:
            self.listbox.insert('end', '0x%08X' % addr)

    def clear(self):
        self.cands = []
        self._show()
        self.say('列表已清空。')


def main():
    root = tk.Tk()
    try:
        root.iconbitmap(default='')
    except Exception:
        pass
    Trainer(root)
    root.mainloop()


if __name__ == '__main__':
    main()
